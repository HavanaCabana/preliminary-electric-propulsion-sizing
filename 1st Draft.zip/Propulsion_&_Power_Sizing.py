'''
Main outouts:
1. Solar array area
2. Power cell mass
3. Battery mass
4. PPU mass
5. Propellant mass
6. Power required for the transfer

Inputs required:
1. Thrust from Orbital transfer
2. Transfer time
'''

import Propulsive_properties as PP
import Orbital_transfer as OT

X_e = 0.65
X_d = 0.85

'Mass flow rate, kg/s'
m_dot = OT.T / OT.c
'Additional fuel reserves percentage'
m_reserves = 1.4

'Solar cells efficiency'
eta_cells_S = 0.18
'Inherent degradation'
I_d = 0.77
'Solar input power density, W/m^2'
p_sun = 1358

'Specific energy density of NiH2 (Nickel-hydrogen) batteries, W.hr/kg'
C_batteries = 50
'Depth-of-discharge of NiH2 (Nickel-hydrogen) batteries'
DOD = 0.75
'Power transfer efficiency'
n = 0.9

'Power required for the propulsion system, W'
P = (OT.T**2) / (2 * m_dot * PP.eta)

'Power required for each orbit, W'
'Intialisation'
P_saArray = []
for i in range(0, OT.orbit-1):
    T_e = OT.t_eclipseENTER[i]
    T_d = OT.t_eclipseLEAVE[i]

    P_sa = P * ((T_e / X_e) + (T_d / X_d)) / T_d

    P_saArray.append(P_sa)

'Power generated per area by the solar arrays, W/m^2'
P_0 = eta_cells_S * p_sun * I_d
'Area of the solar cells, m^2'
A_cells_S = max(P_saArray) / P_0
'Mass of the solar array, kg'
m_cells_req = 0.04 * max(P_saArray)

'Battery capacity'
Cr = (P * (max(OT.t_eclipseENTER))/60**2) / (DOD * n)
'Mass of the batteries required, kg'
m_batteries = Cr / C_batteries

'Propellant mass, kg'
m_propellant = (m_dot * OT.t) * m_reserves
'Thruster mass, kg'
m_thruster = PP.m_thruster * (P * 10**-3)
'PPU mass, kg'
m_PPU = PP.m_ppu * (P * 10**-3)
'Misc. mass, kg'
m_misc = PP.m_misc * (P * 10**-3)

'Total thruster mass, kg'
m_total = m_misc + m_PPU + m_thruster + m_propellant + m_batteries + m_cells_req

print("Area of the solar cells:", round(A_cells_S, 2), "m^2")
print("Mass of the solar cells required:", round(m_cells_req, 2),"kg")
print("Mass of the batteries required:", round(m_batteries, 2),"kg")
print("Propellant mass required for transfer w/", round((m_reserves - 1), 1) * 100, "% reserves:",round(m_propellant, 2), "kg")
print("Thruster mass:", round(m_thruster, 2), "kg")
print("PPU mass:", round(m_PPU, 2), "kg")
print("Misc. mass:", round(m_misc, 2), "kg")
print("TOTAL THRUSTER mass:", round(m_total, 2), "kg")