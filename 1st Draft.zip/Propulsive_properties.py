''' Propulsive properties of a typical Ion propellant thruster'''

'Specific impulse, seconds'
ISP = 2800
'Efficiency'
eta = 0.65
'Thruster mass, kg/kW'
m_thruster = 4.5
'PPU mass, kg/kW'
m_ppu = 8
'Misc. mass, kg/kW'
m_misc = 10

'''
'Lifetime, hours'
lifetime =
'''