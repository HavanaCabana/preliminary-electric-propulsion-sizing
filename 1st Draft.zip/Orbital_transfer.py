import math as m
import Propulsive_properties as PP

' Inputs '
mew = 3.986004415e+14
'Sum of gravitational parameters, m3 s^-2'
r_earth = 6378136.3
r0 = r_earth + (10000 * 10**3)
'Initial orbit, m'
r1 = 42164 * 10**3
'Geosynchronous orbit, m'

m_0 = 2000
'Initial mass of the spacecraft, kg'
g = 9.80665
'Gravitational acceleration, m/s^2'
c = PP.ISP * g
'Exit velocity, m/s'

t_transfer = 250
"Orbital transfer time, days"
t = t_transfer * 60**2 * 24
'Orbital transfer time, s'

v_chg = m.sqrt(mew / r1) - m.sqrt(mew / r0)
T = (m_0 * c / t) * (1 - m.exp(v_chg / c))

''' ORBITAL TRANSFER '''
r = r0
m_1 = m_0
orbit = 0
t_store = []
t_eclipseENTER = []
t_eclipseLEAVE = []
timesun = 0
timein = 0

while r < r1:
    orbit += 1
    t_period = 2 * m.pi * m.sqrt((r**3) / mew)
    r = mew * ((c * m.log(1 - (t_period * T / (m_1 * c))) + m.sqrt(mew / r)) **-2)
    m_1 -= T * t_period / c

    t_store.append(t_period)

    theta = m.asin(r_earth/r)

    if orbit == 1:
        timesun = t_period * theta/(2*m.pi)
        timein = 0
    else:
        timesun += t_period
        timein += - t_period*theta/(2*m.pi)
    timeout = timesun + t_period*theta/(2*m.pi)

    t_eclipseENTER.append(timein)
    t_eclipseLEAVE.append(timeout)

print("Total amount of orbits to complete transfer:", orbit)
print("Total time to transfer:", t_transfer, "days")
print("Total thrust required for transfer:", round(T, 2), "N")