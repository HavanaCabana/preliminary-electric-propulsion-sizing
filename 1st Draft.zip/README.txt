To run the code:
Open all files and then run the Propulsion_&_Power_Sizing.py file